﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Text;
using NetworkPinger.Loggers;
using NetworkPinger.Pingers;

namespace NetworkPinger
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			var fileLogger = new FileLogger ("log.txt", new WithDateFormatter());
			var consoleLogger = new ConsoleLogger (new WithDateFormatter());
			var pinger = new Pinger ();

			var hosts = HostsReader.ReadFromFile ("hosts.txt");

            if(hosts.Count <= 0)
                throw new Exception("Hosts list is empty");

			while (true)
			{
				StringBuilder sb = new StringBuilder ("scanning started");
				foreach (var host in hosts)
				{
					var result = pinger.Ping (host);
					sb.Append ($"\n\t{result.ToString()}");
				}
				var message = sb.ToString ();
				fileLogger.Write (message);
				consoleLogger.Write (message);

				Thread.Sleep (30000);
			}
		}
	}
}
