﻿using System;
using System.Collections.Generic;
using System.IO;

namespace NetworkPinger
{
	public class HostsReader
	{
		public static List<string> ReadFromFile(string path)
		{
			return new List<string> (File.ReadAllLines (path));
		}
	}
}

