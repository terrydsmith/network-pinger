﻿using System;
using System.Net.NetworkInformation;

namespace NetworkPinger.Pingers
{
	public class Pinger : IPinger
	{
		private Ping _pingSender;

		public Pinger ()
		{
			_pingSender = new Ping ();
		}

		public PingStatusReport Ping (string host)
		{
			try 
			{
				var pingReplay = _pingSender.Send (host, 3000);
				var status = pingReplay.Status;
				var isSuccess = status == IPStatus.Success;

				return new PingStatusReport (host, status.ToString(), isSuccess);
			} 
			catch (Exception ex) 
			{
				return new PingStatusReport (host, ex.Message, false);
			}

		}
	}
}

