﻿using System;

namespace NetworkPinger.Pingers
{
	public interface IPinger
	{
		PingStatusReport Ping(string host);
	}
}

