﻿using System;

namespace NetworkPinger.Pingers
{
	public class PingStatusReport
	{
		private string _host;
		private bool _isSuccess;
		private string _description;

		public PingStatusReport (string host, string description, bool isSuccess)
		{
			_description = description;
			_host = host;
			_isSuccess = isSuccess;
		}

		public bool IsSuccess()
		{
			return _isSuccess;
		}

		public override string ToString ()
		{
			var status = _isSuccess ? "OK" : "FAIL";

			if (_isSuccess)
				return String.Format ("{0}\t{1}", status, _host);
			else
				return String.Format ("{0}\t{1}, reason: {2}", status, _host, _description);
		}
	}
}