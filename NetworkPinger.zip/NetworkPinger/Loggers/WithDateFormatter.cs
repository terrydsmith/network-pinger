﻿using System;

namespace NetworkPinger.Loggers
{
	public class WithDateFormatter : IMessageFormatter
	{
		private const string MessageLogFormat = "[{0}] {1}";
		private const string DateFormat = "dd.MM.yy HH:mm:ss";

		public string Format(string message)
		{
			return String.Format (MessageLogFormat, DateTime.Now.ToString (DateFormat), message);
		}
	}
}

