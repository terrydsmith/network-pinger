﻿using System;

namespace NetworkPinger.Loggers
{
	public interface ILogger
	{
		void Write(string message);
	}
}

