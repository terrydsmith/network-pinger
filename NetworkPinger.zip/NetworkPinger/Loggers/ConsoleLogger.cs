﻿using System;

namespace NetworkPinger.Loggers
{
	public class ConsoleLogger : ILogger
	{
		IMessageFormatter _messageFormatter;

		public ConsoleLogger (IMessageFormatter messageFormatter)
		{
			_messageFormatter = messageFormatter;	
		}

		public void Write (string message)
		{
			message = _messageFormatter.Format (message);
			Console.WriteLine(message);
		}
	}
}

