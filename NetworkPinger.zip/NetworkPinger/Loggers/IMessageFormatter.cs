using System;

namespace NetworkPinger.Loggers
{

	public interface IMessageFormatter
	{
		string Format (string message);
	}
}
