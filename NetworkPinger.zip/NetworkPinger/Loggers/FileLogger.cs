﻿using System;
using System.IO;

namespace NetworkPinger.Loggers
{
	public class FileLogger : ILogger
	{
		private string _fileName;
		private IMessageFormatter _messageFormatter;

		public FileLogger (string fileName, IMessageFormatter messageFormatter)
		{
			_messageFormatter = messageFormatter;
			_fileName = fileName;
		}

		public void Write (string message)
		{
			using (var writer = new StreamWriter (_fileName, true)) 
			{
				writer.WriteLine (_messageFormatter.Format(message));
			}
		}
	}
}

